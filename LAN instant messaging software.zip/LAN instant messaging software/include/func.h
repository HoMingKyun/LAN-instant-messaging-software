#ifndef __FUNC_H__
#define __FUNC_H__

#include <stdio.h>
#include <sys/types.h>         
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/stat.h>
#include <fcntl.h>

#define BUF_SIZE 1024  
#define ZUBO_IP "224.0.0.10" 		//组播IP
#define GUANGBO_IP "192.168.16.255" //广播IP
#define DANBO_PORT 5444  			//单播端口号
#define ZUBO_PORT 5666				//组播端口号
#define GUANGBO_PORT 5777 			//广播端口号


//声明一个双向循环链表的节点结构体
typedef struct client_list
{
	// 1.数据域
	char client_ip[20];		//存储IP
	char client_name[20];	//存储昵称
	int client_port;		//存储端口号

	// 2.指针域
	struct client_list *prev;	//上个节点的地址
	struct client_list *next;	//下个节点的地址
}node_st, *node_pt;

node_pt head;		//定义链表头结点全局变量

char *myip;			//定义自己IP全局变量
char *myname;		//定义自己昵称全局变量

node_pt link_list_init(void);//初始化链表

void link_list_show(node_pt head);//显示数据域所有成员数据（往后遍历）

void link_list_add(node_pt head,char *new_ip,char *new_name,int new_port);  //添加好友（添加到链表尾）

void link_list_del(node_pt head,char *old_ip);  //删除好友

char *link_list_check_ip(node_pt head,char *old_ip);  //IP查找好友返回姓名（用于打印显示昵称）

void link_list_find(node_pt head,char *friend) ; //查找好友

void link_list_exit(node_pt head) ; //删除链表

void *danbo_fun(void *arg);  //接收单播

void *zubo_fun(void *arg) ; //接收组播

void *guangbo_fun(void *arg) ; //接收广播

#endif 


