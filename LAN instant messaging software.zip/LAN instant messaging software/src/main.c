#include "func.h"

int main(int argc,char *argv[])
{
	if(argc != 3)
	{
		printf("%s <IP> <name>",argv[0]);
		return -1;
	}
	head = link_list_init();
	myip = argv[1];
	myname = argv[2];
	//1,创建三条线程分别接收广播数据、组播和单播数据
	pthread_t tid1,tid2,tid3;
	pthread_create(&tid1, NULL, danbo_fun, NULL);	 //单波接收
	pthread_create(&tid2, NULL, zubo_fun, NULL);	 //组波接收
	pthread_create(&tid3, NULL, guangbo_fun, NULL);  //广播接收
	
	//1) 创建UDP套接字
	int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd < 0)
	{
		perror("socket main failed");
		return -1;
	}
	//设置套接字的广播属性
	int on = 1;
	setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, (void *)&on, sizeof(on));

	//2) 准备三个结构体： 广播地址结构体， 单播地址结构体，组播结构体
	struct sockaddr_in Broad_addr, Single_addr,mutil_addr;
	socklen_t addrlen = sizeof(Broad_addr);
	
	Broad_addr.sin_family = AF_INET;
	Broad_addr.sin_port = htons(GUANGBO_PORT);
	Broad_addr.sin_addr.s_addr = inet_addr(GUANGBO_IP);  //广播IP
	
	Single_addr.sin_family = AF_INET;
	Single_addr.sin_port = htons(DANBO_PORT);
	
	//初始化组播结构体
	struct ip_mreq mutil_mrep;
	mutil_mrep.imr_multiaddr.s_addr = inet_addr(ZUBO_IP);  //组播IP
	mutil_mrep.imr_interface.s_addr = htonl(INADDR_ANY);  //自己IP
	
	setsockopt(sockfd,IPPROTO_IP,IP_ADD_MEMBERSHIP,(void *)&mutil_mrep,sizeof(mutil_mrep)); //设置组播属性
	
	//3)  往组内发送组播数据
	mutil_addr.sin_family = AF_INET;  //IPV4地址结构体
	mutil_addr.sin_port = htons(ZUBO_PORT);  
	mutil_addr.sin_addr.s_addr = inet_addr(ZUBO_IP);
	
	int flag;
	char buf[BUF_SIZE];
	char online[20] = "CLIENT_ONLINE\n";
	char buf_data[20];
	char a[] = {"CLIENT_OFFLINE\n"};
	sprintf(buf,"%s%s",online,argv[2]);
	
	sendto(sockfd,buf,sizeof(buf),0,(struct sockaddr *)&Broad_addr,addrlen);  //发送广播上线
	
	while(1)
	{
		printf("\nPlease enter the digital selection function:\n");  //请输入数字选择功能
		printf("1:Single  2:Mrep  3:Broad  4:Friends list  5:Find friend  6:off line\n");
		scanf("%d",&flag);
		while(getchar() != '\n');	//清空输入缓冲区
		if(flag == 1) 
		{
			bzero(buf_data,sizeof(buf_data));
			printf("Please enter the IP:");
			scanf("%s",buf_data);
			while(getchar() != '\n');	//清空输入缓冲区
			Single_addr.sin_addr.s_addr = inet_addr(buf_data);  //设置单播对方IP
			
			while(1)//循环发送单播数据
			{
				bzero(buf, sizeof(buf));
				fgets(buf, sizeof(buf), stdin);
				sendto(sockfd, buf, sizeof(buf), 0,(struct sockaddr *)&Single_addr, addrlen);
				if(strcmp("BYEBYE\n", buf) == 0)
					break;
			}
		}
		if(flag == 2)  //循环发送组播数据
		{
			while(1)
			{
				bzero(buf,sizeof(buf));
				fgets(buf,sizeof(buf),stdin);
				sendto(sockfd,buf,sizeof(buf),0,(struct sockaddr *)&mutil_addr,addrlen);
				if(strcmp("BYEBYE\n", buf) == 0)
					break;
			}
		}
		if(flag == 3)//循环发送广播数据
		{
			while(1)
			{
				bzero(buf,sizeof(buf));
				fgets(buf,sizeof(buf),stdin);
				sendto(sockfd,buf,sizeof(buf),0,(struct sockaddr *)&Broad_addr,addrlen);
				if(strcmp("BYEBYE\n", buf) == 0)
					break;
			}
		}
		if(flag == 4)  //显示好友列表
		{
			link_list_show(head);
		}
		if(flag == 5)  //通过IP查找好友
		{
			bzero(buf_data,sizeof(buf_data));
			printf("Please enter the IP or name:\n");
			scanf("%s",buf_data);
			while(getchar() != '\n');	//清空输入缓冲区
			link_list_find(head,buf_data);
		}
		if(flag == 6)  //下线
		{
			sendto(sockfd,a,sizeof(a),0,(struct sockaddr *)&Broad_addr,addrlen);//发送广播说下线了
			exit(0);
		}
	}
	while(1)
	{
		pause();
	}
	
	close(sockfd);
	link_list_exit(head); //关闭链表
	
	return 0;
}