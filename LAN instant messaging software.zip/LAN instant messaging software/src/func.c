#include "func.h"

//显示数据域所有成员数据（往后遍历）
void link_list_show(node_pt head)
{
	//循环遍历，直到尾节点（next指向head）
	node_pt pos;
	pos = head->next;
	printf("****************************************************************************\n");
	if(pos == head)
		printf("No friends online\n");
	for(; pos!=head; pos=pos->next)
		printf("%s  %d  %s\n", pos->client_ip,pos->client_port,pos->client_name);
	printf("****************************************************************************\n");
}

//初始化链表
node_pt link_list_init(void)
{
	// 1.给头节点申请一个堆空间
	node_pt h = malloc(sizeof(node_st));
	if(h == NULL)
	{
		perror("head malloc failed");
		return NULL;
	}

	// 2.next指向自身，prev指向自身
	h->prev = h;
	h->next = h;	

	// 3.返回头节点地址
	return h;
}

void link_list_add(node_pt head,char *new_ip,char *new_name,int new_port)  //添加好友（添加到链表尾）
{
	node_pt new_node = malloc(sizeof(node_st));
	if(new_node == NULL)
	{
		perror("new_node malloc failed");
		return;
	}
	
	strcpy(new_node->client_ip,new_ip);
	strcpy(new_node->client_name,new_name);
	new_node->client_port = new_port;
	
	new_node->prev = head->prev;
	new_node->next = head;
	
	head->prev->next = new_node;
	head->prev = new_node; 
}

void link_list_del(node_pt head,char *old_ip)  //删除好友
{
	if(head->next == head)
	{
		perror("del no data");
		return;
	}
	
	node_pt pos = head->next;
	while(1)
	{
		if(pos == head)
		{
			printf("del Can't find\n");
			return;
		}
		if(strcmp(pos->client_ip,old_ip) == 0)
			break;
		pos = pos->next;
	}
	
	pos->next->prev = pos->prev;
	pos->prev->next = pos->next;
	free(pos);
}

char *link_list_check_ip(node_pt head,char *old_ip)  //IP查找好友返回姓名（用于打印显示昵称）
{
	if(head->next == head)
	{
		return NULL;
	}
	
	node_pt pos = head->next;
	while(1)
	{
		if(pos == head)
		{
			return NULL;
		}
		if(strcmp(pos->client_ip,old_ip) == 0)
			break;
		pos = pos->next;
	}
	return pos->client_name;
}

void link_list_find(node_pt head,char *friend)  //查找好友
{
	if(head->next == head)
	{
		printf("No friends online\n");
		return;
	}
	node_pt pos = head->next;
	while(1)
	{
		if(pos == head)
		{
			printf("No such person.\n");
			return;
		}
		if(strcmp(pos->client_ip,friend) == 0 || strcmp(pos->client_name,friend) == 0)
		{
			
		}
			break;
		pos = pos->next;
	}
	printf("%s  %d  %s\n",pos->client_ip,pos->client_port,pos->client_name);
	return;
}

void link_list_exit(node_pt head)  //删除链表
{
	node_pt pos;
	node_pt temp;
	for(pos = head->next;pos != head;pos = pos->next)
	{
		temp = pos;
		free(pos);
		pos = temp;
	}
	
	free(head);
}

void *danbo_fun(void *arg)  //接收单播
{
	//1,创建一个UDP套接字
	int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd < 0)
	{
		perror("socket danbo failed");
		return NULL;
	}
	
	//2,bind自己的端口号和IP
	struct sockaddr_in single_addr,send_addr;
	socklen_t addrlen = sizeof(single_addr);
	
	single_addr.sin_family = AF_INET;
	single_addr.sin_port = htons(DANBO_PORT);
	single_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	if(bind(sockfd, (struct sockaddr *)&single_addr, addrlen) < 0)
	{		
		perror("bind danbo failed");
		return NULL;
	}
	
	//3,循环从UDP套接字中接收数据
	char ip_addr[20];
	char buf[BUF_SIZE];
	char online_buf[20];
	char name_addr[20];
	while(1)
	{
		bzero(online_buf,sizeof(online_buf));
		bzero(ip_addr, sizeof(ip_addr));
		bzero(buf, sizeof(buf));
		bzero(name_addr, sizeof(name_addr));
		recvfrom(sockfd, buf, sizeof(buf), 0,(struct sockaddr *)&send_addr, &addrlen);	//client 结构体存放对方的ip和端口号
		inet_ntop(AF_INET, &send_addr.sin_addr, ip_addr, sizeof(ip_addr));
		sscanf(buf,"%s%s", online_buf,name_addr);
		
		if(strcmp("MY_FRIEND",online_buf) == 0)  //如果接收到对方发送单播“MY_FRIEND”那就加入好友列表
		{
			link_list_add(head,ip_addr,name_addr,ntohs(send_addr.sin_port));
		}
		else
			printf("%s %d %s signal:%s",ip_addr,ntohs(send_addr.sin_port),link_list_check_ip(head,ip_addr),buf);
	}
}

void *zubo_fun(void *arg)  //接收组播
{
	//1,创建UDP套接字
	int sockfd = socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd == -1)
	{
		perror("socket zubo failed");
		return NULL;
	}
	
	//2,bind自己的ip和端口号
	//初始化组播结构体
	struct ip_mreq mutil_mrep;
	mutil_mrep.imr_multiaddr.s_addr = inet_addr(ZUBO_IP);
	mutil_mrep.imr_interface.s_addr = htonl(INADDR_ANY);
	
	setsockopt(sockfd,IPPROTO_IP,IP_ADD_MEMBERSHIP,(void *)&mutil_mrep,sizeof(mutil_mrep)); //设置组播属性

	struct sockaddr_in recv_addr,send_addr;
	socklen_t addrlen = sizeof(recv_addr);
	
	recv_addr.sin_family = AF_INET;  //IPV4地址结构体
	recv_addr.sin_port = htons(ZUBO_PORT);  
	recv_addr.sin_addr.s_addr = htonl(INADDR_ANY);  //INADDR_ANY存储本机IP
	
	if(bind(sockfd, (struct sockaddr *)&recv_addr, addrlen) != 0)
	{
		perror("bind zubo failed");
		return NULL;
	}
	
	//3,循环接收数据
	char buf[BUF_SIZE];
	char send_ip[20];
	while(1)
	{
		bzero(send_ip,sizeof(send_ip));
		bzero(buf,sizeof(buf));
		recvfrom(sockfd,buf,sizeof(buf),0,(struct sockaddr *)&send_addr,&addrlen);
		inet_ntop(AF_INET,&send_addr.sin_addr,send_ip,sizeof(send_ip));
		if(strcmp(send_ip,myip) == 0)  //剔除自己的广播
			continue;
		printf("%s %d %s mutil:%s",send_ip,ntohs(send_addr.sin_port),link_list_check_ip(head,send_ip),buf);
	}
}

void *guangbo_fun(void *arg)  //接收广播
{
	//1,创建一个UDP套接字
	int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd < 0)
	{
		perror("socket guangbo failed");
		return NULL;
	}
	
	//2,设置单播广播结构体
	struct sockaddr_in signal_addr;
	
	signal_addr.sin_family = AF_INET;	//IPV4地址协议族
	signal_addr.sin_port = htons(DANBO_PORT);
	
	//2,bind自己的端口号和IP
	struct sockaddr_in Broad_addr, Recv_addr;
	socklen_t addrlen = sizeof(Broad_addr);
	
	Broad_addr.sin_family = AF_INET;
	Broad_addr.sin_port = htons(GUANGBO_PORT);
	Broad_addr.sin_addr.s_addr = inet_addr(GUANGBO_IP);
	
	if(bind(sockfd, (struct sockaddr *)&Broad_addr, addrlen) < 0)
	{		
		perror("bind guangbo failed");
		return NULL;
	}
	
	//3,循环接收数据,解析第一个包，判断是上线还是下线，得到ip和端口号
	char buf[BUF_SIZE];
	char signal_buf[20];
	char name_addr[20];
	char ip_addr[20];
	char mf[] = "MY_FRIEND\n";
	char mf_buf[BUF_SIZE];
	
	sprintf(mf_buf,"%s%s",mf,myname);
	
	while(1)
	{
		bzero(buf,sizeof(buf));
		bzero(ip_addr,sizeof(ip_addr));
		bzero(signal_buf,sizeof(signal_buf));
		bzero(name_addr,sizeof(name_addr));
		recvfrom(sockfd,buf,sizeof(buf),0,(struct sockaddr *)&Recv_addr,&addrlen);
		inet_ntop(AF_INET,&Recv_addr.sin_addr,ip_addr,sizeof(ip_addr));
		sscanf(buf,"%s%s", signal_buf,name_addr);
		
		if(strcmp(ip_addr,myip) == 0)  //剔除自己的广播
			continue;
		if(strcmp("CLIENT_ONLINE",signal_buf) == 0)  //如果是上线信号那就加入好友列表
		{
			printf("%s %s on line\n",ip_addr,name_addr);
			link_list_add(head,ip_addr,name_addr,ntohs(Recv_addr.sin_port));
			
			signal_addr.sin_addr.s_addr = inet_addr(ip_addr);  //设置对方IP
			sendto(sockfd, mf_buf, sizeof(mf_buf), 0, (struct sockaddr *)&signal_addr, addrlen);//发送单波信号MY_FRIEND给新好友
		}
		else if(strcmp("CLIENT_OFFLINE",signal_buf) == 0)  //如果下线就从好友列表删除
		{
			printf("%s %s off line\n",ip_addr,link_list_check_ip(head,ip_addr));
			link_list_del(head,ip_addr);
		}
		else 
			printf("%s %d %s Broad:%s", ip_addr, ntohs(Recv_addr.sin_port),link_list_check_ip(head,ip_addr), buf);
	}
}